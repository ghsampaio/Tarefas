

public abstract class Figura2D extends Figura {

	public abstract double area();
	
}
