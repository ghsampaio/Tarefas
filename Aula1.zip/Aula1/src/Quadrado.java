
public class Quadrado extends Poligono implements Diagonal{

	public Quadrado(int lado) {
		super(lado, lado);
	}
	
	public double area() {
		return super.area();
	}

	@Override
	public double calculaDiagonal() {
		return 0;
	}
	
	public double perimetro() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
