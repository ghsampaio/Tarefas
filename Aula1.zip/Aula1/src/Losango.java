public class Losango extends Poligono {

	public Losango(int base, int altura) {
		super(base, altura);
	}

	@Override
	public double area() {
		return super.area();
	}
	
	public double perimetro() {
		// TODO Auto-generated method stub
		return 0;
	}

}
