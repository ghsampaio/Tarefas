import java.util.ArrayList;

public class Geometria {
	
public static void main(String[] args) {
		
		ArrayList <Figura2D> figura2d = new ArrayList<>();
		ArrayList <Figura3D> figura3d = new ArrayList<>();
		figura2d.add(new Quadrado(5));
		figura2d.add(new Triangulo(4, 3));
		figura2d.add(new Losango(4, 8));
		figura2d.add(new Retangulo(7, 2));
		figura3d.add(new Circulo(4));
		figura2d.add(new Trapezio(8, 3, 4, 3));
		
		System.out.println("-o-o-o-o-o-o-o-o- Figuras 2D -o-o-o-o-o-o-o-o-o-");
		for (Figura2D fig:figura2d) {
			System.out.println("A �rea da figura �: "  + fig.area() + "cm�");
			
			if (fig instanceof Diagonal) {
				System.out.println("E sua diagonal vale: " + ((Diagonal)fig).calculaDiagonal());
				System.out.println("------------------------");
			} else {
				System.out.println("------------------------");
			}
		}
		System.out.println("-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-");
	}

}
