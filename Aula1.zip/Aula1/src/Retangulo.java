
public class Retangulo extends Poligono {

	public Retangulo(int base, int altura) {
		super(base, altura);
	}

	@Override
	public double area() {
		return super.area();
	}

	public double perimetro() {
		// TODO Auto-generated method stub
		return 0;
	}
}
