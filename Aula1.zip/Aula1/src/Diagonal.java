
public interface Diagonal {
	double calculaDiagonal();
}
