public class Circulo extends Figura3D {

	private int raio;
	
	public Circulo(int raio) {
		this.raio = raio;
	}

	public int getRaio() {
		return raio;
	}

	public void setRaio(int raio) {
		this.raio = raio;
	}

	@Override
	public double perimetro() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculaVolume() {
		// TODO Auto-generated method stub
		return 0;
	}
}
